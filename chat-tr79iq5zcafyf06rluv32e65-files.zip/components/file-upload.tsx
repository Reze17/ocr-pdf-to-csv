"use client"

import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import { Upload, File, X, FileText, Image, FileSpreadsheet } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void
  onProcessingComplete: (results: any[]) => void
}

interface UploadedFile {
  file: File
  id: string
  progress: number
  status: 'uploading' | 'processing' | 'completed' | 'error'
  result?: any
}

const FileUpload = ({ onFilesSelected, onProcessingComplete }: FileUploadProps) => {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  console.log("FileUpload component rendered", { uploadedFiles, isProcessing })

  const onDrop = useCallback((acceptedFiles: File[]) => {
    console.log("Files dropped:", acceptedFiles)
    
    const newFiles = acceptedFiles.map(file => ({
      file,
      id: Math.random().toString(36).substr(2, 9),
      progress: 0,
      status: 'uploading' as const
    }))

    setUploadedFiles(prev => [...prev, ...newFiles])
    onFilesSelected(acceptedFiles)
    toast.success(`${acceptedFiles.length} file(s) added successfully`)
  }, [onFilesSelected])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.tiff', '.bmp'],
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: true
  })

  const removeFile = (id: string) => {
    console.log("Removing file:", id)
    setUploadedFiles(prev => prev.filter(f => f.id !== id))
  }

  const processFiles = async () => {
    console.log("Starting file processing")
    setIsProcessing(true)
    const results: any[] = []

    for (const uploadedFile of uploadedFiles) {
      if (uploadedFile.status !== 'uploading') continue

      try {
        console.log("Processing file:", uploadedFile.file.name)
        
        // Update status to processing
        setUploadedFiles(prev => 
          prev.map(f => f.id === uploadedFile.id ? { ...f, status: 'processing', progress: 50 } : f)
        )

        const formData = new FormData()
        formData.append('file', uploadedFile.file)

        const response = await fetch('/api/ocr', {
          method: 'POST',
          body: formData,
        })

        if (!response.ok) {
          throw new Error(`OCR processing failed: ${response.statusText}`)
        }

        const result = await response.json()
        console.log("OCR result received:", result)

        // Update status to completed
        setUploadedFiles(prev => 
          prev.map(f => f.id === uploadedFile.id ? 
            { ...f, status: 'completed', progress: 100, result } : f
          )
        )

        results.push({
          fileName: uploadedFile.file.name,
          ...result
        })

      } catch (error) {
        console.error("Error processing file:", error)
        setUploadedFiles(prev => 
          prev.map(f => f.id === uploadedFile.id ? { ...f, status: 'error', progress: 0 } : f)
        )
        toast.error(`Failed to process ${uploadedFile.file.name}`)
      }
    }

    setIsProcessing(false)
    onProcessingComplete(results)
    toast.success('Processing completed!')
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image className="w-4 h-4" />
    if (file.type === 'application/pdf') return <FileText className="w-4 h-4" />
    if (file.type.includes('word')) return <File className="w-4 h-4" />
    return <File className="w-4 h-4" />
  }

  const getStatusColor = (status: UploadedFile['status']) => {
    switch (status) {
      case 'uploading': return 'bg-amber-500'
      case 'processing': return 'bg-ocean-500'
      case 'completed': return 'bg-emerald-500'
      case 'error': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  return (
    <div className="space-y-6">
      {/* Drop Zone */}
      <Card className="transition-all duration-300 hover:shadow-lg">
        <CardContent className="p-8">
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-xl p-12 text-center cursor-pointer
              transition-all duration-300 bg-gradient-to-br from-slate-50 to-white
              hover:from-ocean-50 hover:to-blue-50 hover:border-ocean-300
              ${isDragActive ? 'border-ocean-500 bg-ocean-50 animate-pulse-glow' : 'border-slate-300'}
            `}
          >
            <input {...getInputProps()} />
            <motion.div
              initial={{ scale: 1 }}
              animate={{ scale: isDragActive ? 1.05 : 1 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              <div className="mx-auto w-16 h-16 bg-ocean-gradient rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-white" />
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  {isDragActive ? 'Drop files here!' : 'Upload your documents'}
                </h3>
                <p className="text-slate-600 mb-4">
                  Drag & drop files or click to browse
                </p>
                <div className="flex flex-wrap justify-center gap-2 text-sm text-slate-500">
                  <Badge variant="outline" className="bg-white">PDF</Badge>
                  <Badge variant="outline" className="bg-white">DOCX</Badge>
                  <Badge variant="outline" className="bg-white">PNG</Badge>
                  <Badge variant="outline" className="bg-white">JPEG</Badge>
                  <Badge variant="outline" className="bg-white">TIFF</Badge>
                </div>
              </div>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      {/* File List */}
      <AnimatePresence>
        {uploadedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-slate-900">
                Uploaded Files ({uploadedFiles.length})
              </h3>
              <Button 
                onClick={processFiles}
                disabled={isProcessing || uploadedFiles.every(f => f.status !== 'uploading')}
                className="bg-ocean-gradient hover:shadow-lg transition-all duration-300"
              >
                {isProcessing ? 'Processing...' : 'Process Files'}
                <FileSpreadsheet className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <div className="space-y-3">
              {uploadedFiles.map((uploadedFile) => (
                <motion.div
                  key={uploadedFile.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getFileIcon(uploadedFile.file)}
                      <div>
                        <p className="font-medium text-slate-900">{uploadedFile.file.name}</p>
                        <p className="text-sm text-slate-500">
                          {(uploadedFile.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(uploadedFile.status)}>
                        {uploadedFile.status}
                      </Badge>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(uploadedFile.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {uploadedFile.status === 'processing' && (
                    <div className="mt-4">
                      <div className="flex justify-between text-sm text-slate-600 mb-1">
                        <span>Processing...</span>
                        <span>{uploadedFile.progress}%</span>
                      </div>
                      <Progress value={uploadedFile.progress} className="h-2" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default FileUpload