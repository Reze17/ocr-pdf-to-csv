"use client"

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { Download, FileText, Eye, RotateCcw } from 'lucide-react'
import { motion } from 'framer-motion'
import Papa from 'papaparse'

interface ResultsViewerProps {
  results: any[]
  onReset: () => void
}

const ResultsViewer = ({ results, onReset }: ResultsViewerProps) => {
  const [selectedResult, setSelectedResult] = useState(0)

  console.log("ResultsViewer rendered", { results, selectedResult })

  const downloadCSV = (result: any) => {
    console.log("Downloading CSV for result:", result)
    
    try {
      // Convert extracted text to CSV format
      const lines = result.extractedText.split('\n').filter((line: string) => line.trim())
      const csvData = lines.map((line: string, index: number) => ({
        'Line Number': index + 1,
        'Content': line.trim()
      }))

      const csv = Papa.unparse(csvData)
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob)
        link.setAttribute('href', url)
        link.setAttribute('download', `${result.fileName.replace(/\.[^/.]+$/, '')}_extracted.csv`)
        link.style.visibility = 'hidden'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
      
      toast.success('CSV file downloaded successfully!')
    } catch (error) {
      console.error('Error downloading CSV:', error)
      toast.error('Failed to download CSV file')
    }
  }

  const downloadAllCSV = () => {
    console.log("Downloading all results as CSV")
    
    try {
      // Combine all results into one CSV
      const allData: any[] = []
      
      results.forEach(result => {
        const lines = result.extractedText.split('\n').filter((line: string) => line.trim())
        lines.forEach((line: string, index: number) => {
          allData.push({
            'File Name': result.fileName,
            'Line Number': index + 1,
            'Content': line.trim()
          })
        })
      })

      const csv = Papa.unparse(allData)
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob)
        link.setAttribute('href', url)
        link.setAttribute('download', 'all_extracted_data.csv')
        link.style.visibility = 'hidden'
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
      }
      
      toast.success('Combined CSV file downloaded successfully!')
    } catch (error) {
      console.error('Error downloading combined CSV:', error)
      toast.error('Failed to download combined CSV file')
    }
  }

  if (results.length === 0) {
    return null
  }

  const currentResult = results[selectedResult]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Processing Results</h2>
          <p className="text-slate-600 mt-1">
            Successfully processed {results.length} file{results.length !== 1 ? 's' : ''}
          </p>
        </div>
        
        <div className="flex space-x-3">
          <Button
            onClick={downloadAllCSV}
            className="bg-success-gradient hover:shadow-lg transition-all duration-300"
          >
            <Download className="w-4 h-4 mr-2" />
            Download All CSV
          </Button>
          
          <Button
            variant="outline"
            onClick={onReset}
            className="hover:bg-slate-50"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Process New Files
          </Button>
        </div>
      </div>

      {/* Results Cards */}
      <div className="grid gap-4">
        {results.map((result, index) => (
          <Card 
            key={index} 
            className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
              selectedResult === index ? 'ring-2 ring-ocean-500 shadow-lg' : ''
            }`}
            onClick={() => setSelectedResult(index)}
          >
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-ocean-600" />
                    {result.fileName}
                  </CardTitle>
                  <CardDescription className="mt-1">
                    Click to view extracted content
                  </CardDescription>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge className="bg-emerald-500">
                    Processed
                  </Badge>
                  <Button
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      downloadCSV(result)
                    }}
                    className="bg-ocean-gradient hover:shadow-md transition-all duration-300"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    CSV
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>

      {/* Detailed View */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Eye className="w-5 h-5 mr-2 text-ocean-600" />
            Detailed View: {currentResult.fileName}
          </CardTitle>
          <CardDescription>
            Review and download the extracted content
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="extracted" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="extracted">Extracted Text</TabsTrigger>
              <TabsTrigger value="preview">CSV Preview</TabsTrigger>
            </TabsList>
            
            <TabsContent value="extracted" className="space-y-4">
              <div className="bg-slate-50 rounded-lg p-4">
                <h4 className="font-semibold text-slate-900 mb-3">Raw Extracted Text</h4>
                <Textarea
                  value={currentResult.extractedText}
                  readOnly
                  className="min-h-[300px] font-mono text-sm bg-white"
                  placeholder="No text extracted"
                />
              </div>
              
              <div className="flex justify-end">
                <Button
                  onClick={() => downloadCSV(currentResult)}
                  className="bg-ocean-gradient hover:shadow-lg transition-all duration-300"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download as CSV
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="preview" className="space-y-4">
              <div className="bg-slate-50 rounded-lg p-4">
                <h4 className="font-semibold text-slate-900 mb-3">CSV Preview</h4>
                <div className="bg-white rounded border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Line #</TableHead>
                        <TableHead>Content</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentResult.extractedText
                        .split('\n')
                        .filter((line: string) => line.trim())
                        .slice(0, 10)
                        .map((line: string, index: number) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{index + 1}</TableCell>
                            <TableCell className="max-w-md truncate">{line.trim()}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                  
                  {currentResult.extractedText.split('\n').filter((line: string) => line.trim()).length > 10 && (
                    <div className="px-4 py-2 bg-slate-50 text-sm text-slate-600 text-center">
                      ... and {currentResult.extractedText.split('\n').filter((line: string) => line.trim()).length - 10} more lines
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export default ResultsViewer