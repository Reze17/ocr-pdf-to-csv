"use client"

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Toaster } from '@/components/ui/sonner'
import { Zap, FileText, Database, Shield, Clock, Sparkles } from 'lucide-react'
import { motion } from 'framer-motion'
import FileUpload from '@/components/file-upload'
import ResultsViewer from '@/components/results-viewer'

export default function Home() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [processingResults, setProcessingResults] = useState<any[]>([])

  console.log("Home page rendered", { selectedFiles, processingResults })

  const handleFilesSelected = (files: File[]) => {
    console.log("Files selected in home:", files)
    setSelectedFiles(files)
  }

  const handleProcessingComplete = (results: any[]) => {
    console.log("Processing completed in home:", results)
    setProcessingResults(results)
  }

  const handleReset = () => {
    console.log("Resetting application state")
    setSelectedFiles([])
    setProcessingResults([])
  }

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Advanced OCR processing with cloud-scale performance"
    },
    {
      icon: FileText,
      title: "Multi-Format Support",
      description: "PDF, DOCX, PNG, JPEG, TIFF - we handle them all"
    },
    {
      icon: Database,
      title: "Structured Output",
      description: "Clean CSV files ready for Excel, databases, or analytics"
    },
    {
      icon: Shield,
      title: "Secure Processing",
      description: "Your documents are processed securely and never stored"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <div className="w-10 h-10 bg-ocean-gradient rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Smart OCR Converter</h1>
                <p className="text-sm text-slate-600">Convert documents to structured CSV data</p>
              </div>
            </motion.div>
            
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                <Clock className="w-3 h-3 mr-1" />
                Real-time Processing
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {processingResults.length === 0 ? (
          <div className="space-y-12">
            {/* Hero Section */}
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center space-y-6"
            >
              <div className="space-y-4">
                <h2 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
                  Transform Documents into
                  <span className="bg-ocean-gradient bg-clip-text text-transparent"> Structured Data</span>
                </h2>
                <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
                  Upload PDFs, Word documents, or images and get clean, organized CSV files 
                  ready for analysis, automation, or record-keeping.
                </p>
              </div>
              
              <div className="flex justify-center space-x-4 text-sm">
                <div className="flex items-center text-slate-600">
                  <Shield className="w-4 h-4 mr-2 text-emerald-500" />
                  Secure & Private
                </div>
                <div className="flex items-center text-slate-600">
                  <Zap className="w-4 h-4 mr-2 text-amber-500" />
                  AI-Powered OCR
                </div>
                <div className="flex items-center text-slate-600">
                  <Database className="w-4 h-4 mr-2 text-ocean-500" />
                  Instant CSV Export
                </div>
              </div>
            </motion.section>

            <Separator className="my-12" />

            {/* Upload Section */}
            <section className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <FileUpload 
                  onFilesSelected={handleFilesSelected}
                  onProcessingComplete={handleProcessingComplete}
                />
              </motion.div>
            </section>

            {/* Features Section */}
            <section className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="text-center"
              >
                <h3 className="text-2xl font-bold text-slate-900 mb-4">
                  Powerful Features for Modern Workflows
                </h3>
                <p className="text-slate-600 max-w-2xl mx-auto">
                  Built with cutting-edge technology to handle your document processing needs
                  efficiently and securely.
                </p>
              </motion.div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-lg transition-all duration-300 bg-white/70 backdrop-blur-sm">
                      <CardHeader className="text-center">
                        <div className="mx-auto w-12 h-12 bg-ocean-gradient rounded-lg flex items-center justify-center mb-4">
                          <feature.icon className="w-6 h-6 text-white" />
                        </div>
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-center">
                          {feature.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </section>
          </div>
        ) : (
          <ResultsViewer 
            results={processingResults}
            onReset={handleReset}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-white/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-slate-600">
            <p>© 2024 Smart OCR Converter. Built with Next.js and modern web technologies.</p>
            <p className="text-sm mt-2">Secure document processing • No data stored • Privacy first</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
