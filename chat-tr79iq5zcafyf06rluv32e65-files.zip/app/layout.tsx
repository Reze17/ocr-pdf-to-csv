import "./globals.css";
import type { Metadata } from "next";
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Smart OCR Converter - Transform Documents to CSV",
  description: "Convert PDFs, DOCX, and images to structured CSV data using advanced OCR technology. Secure, fast, and easy to use.",
  keywords: "OCR, PDF converter, document processing, CSV export, text extraction, data conversion",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
        <body className={inter.className}>{children}</body>
    </html>
  );
}