import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  console.log("OCR API route called")
  
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      console.error("No file provided in request")
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    console.log("Processing file:", file.name, "Size:", file.size, "Type:", file.type)

    // Convert file to base64 for API League
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    
    // For this demo, we'll simulate OCR processing
    // In production, you would integrate with API League or similar service
    const mockExtractedText = await simulateOCR(file, buffer)
    
    console.log("OCR processing completed for:", file.name)
    
    return NextResponse.json({
      success: true,
      extractedText: mockExtractedText,
      fileName: file.name,
      fileSize: file.size,
      processingTime: Date.now()
    })

  } catch (error) {
    console.error('OCR processing error:', error)
    return NextResponse.json(
      { error: 'Failed to process file', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

// Simulate OCR processing - replace with actual API League integration
async function simulateOCR(file: File, buffer: Buffer): Promise<string> {
  console.log("Simulating OCR processing for:", file.name)
  
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 2000))
  
  // Generate mock extracted text based on file type
  if (file.type.startsWith('image/')) {
    return `Document Title: ${file.name.replace(/\.[^/.]+$/, '')}
Date: ${new Date().toLocaleDateString()}
 
Sample extracted text from image:
- Item 1: Product Name A, Quantity: 5, Price: $12.99
- Item 2: Product Name B, Quantity: 3, Price: $8.50
- Item 3: Product Name C, Quantity: 2, Price: $15.00

Total Amount: $89.47
Payment Method: Credit Card
Transaction ID: TXN-${Math.random().toString(36).substr(2, 9).toUpperCase()}

Notes: This is simulated OCR output. In production, this would be real extracted text from your image using API League or similar OCR service.`
  }
  
  if (file.type === 'application/pdf') {
    return `PDF Document Extraction
Title: ${file.name.replace(/\.[^/.]+$/, '')}
Processed: ${new Date().toLocaleString()}

Invoice #INV-${Math.random().toString(36).substr(2, 6).toUpperCase()}
Date: ${new Date().toLocaleDateString()}

Bill To:
John Doe
123 Main Street
Anytown, ST 12345

Description,Quantity,Unit Price,Total
Website Development,1,$2500.00,$2500.00
Hosting Setup,1,$150.00,$150.00
Domain Registration,1,$15.00,$15.00

Subtotal:,$2665.00
Tax (8%):,$213.20
Total:,$2878.20

Payment Terms: Net 30
Due Date: ${new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}

This is simulated PDF text extraction. In production, this would be actual content extracted from your PDF using advanced OCR technology.`
  }
  
  if (file.type.includes('word')) {
    return `Document Title: ${file.name.replace(/\.[^/.]+$/, '')}
Document Type: Word Document
Extracted: ${new Date().toLocaleString()}

Meeting Minutes
Date: ${new Date().toLocaleDateString()}
Time: 2:00 PM - 3:30 PM
Location: Conference Room A

Attendees:
- Sarah Johnson (Project Manager)
- Mike Chen (Developer)
- Lisa Brown (Designer)
- Tom Wilson (QA Lead)

Agenda Items:
1. Project Status Update
2. Sprint Planning
3. Budget Review
4. Timeline Discussion

Action Items:
- Complete API integration by Friday
- Update design mockups
- Schedule user testing session
- Review budget allocation

Next Meeting: ${new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}

This is simulated Word document extraction. In production, this would be actual content extracted from your DOCX file.`
  }
  
  return `Generic Document Extraction
File: ${file.name}
Size: ${(file.size / 1024).toFixed(2)} KB
Processed: ${new Date().toLocaleString()}

Sample extracted content:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco.

Data Table:
Column 1, Column 2, Column 3
Row 1A, Row 1B, Row 1C
Row 2A, Row 2B, Row 2C
Row 3A, Row 3B, Row 3C

This is simulated OCR output for demonstration purposes.`
}